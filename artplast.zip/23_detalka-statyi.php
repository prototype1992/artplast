<!DOCTYPE html>
<html lang="ru">
<head>

    <meta charset="UTF-8">
    <!--<meta name="viewport" content="width=device-width, initial-scale=1.0">-->
    <meta name="description" content="описание страницы">
    <meta name="keywords" content="ключевое слово1, ключевое слово2">

    <title>Карта сайта</title>

    <link rel="stylesheet" href="static/css/style.min.css"/>

</head>
<body>

<div class="wrapper">
    
    <div class="main">
        <div class="all">

            <?php require_once('template/header.php') ?>

            <div class="main-content">
                <div class="container">
                    <aside class="sidebar">

                        <ul class="categories">
                            <li class="categories__item categories__item_drop">
                                <a href="" class="categories__link">
                                    Пакет с петлевой ручкой
                                </a>
                                <div class="sub-category-menu">
                                    <div class="category-arrow"></div>
                                    <div class="sub-category-menu-inner">
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Стакан</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Тарелка</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Hutamaki"</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Наборы одноразовой посуды</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Столовые приборы</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые чашки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Барные украшения</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Ланчбоксы</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда из Литьевого полистерола Кристалл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые лотки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Super Party"</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пакеты с вырубной ручкой
                                </a>
                            </li>
                            <li class="categories__item categories__item_drop">
                                <a href="" class="categories__link">
                                    Пакет майка
                                </a>
                                <div class="sub-category-menu">
                                    <div class="category-arrow"></div>
                                    <div class="sub-category-menu-inner">
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Стакан</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Тарелка</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Hutamaki"</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Наборы одноразовой посуды</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Столовые приборы</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые чашки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Барные украшения</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Ланчбоксы</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда из Литьевого полистерола Кристалл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые лотки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Super Party"</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="categories__item categories__item_drop">
                                <a href="" class="categories__link">
                                    Пленка пищевая
                                </a>
                                <div class="sub-category-menu">
                                    <div class="category-arrow"></div>
                                    <div class="sub-category-menu-inner">
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Стакан</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Тарелка</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Hutamaki"</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Наборы одноразовой посуды</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Столовые приборы</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые чашки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Барные украшения</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Ланчбоксы</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда из Литьевого полистерола Кристалл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые лотки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Super Party"</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="categories__item categories__item_drop">
                                <a href="" class="categories__link">
                                    Скотч
                                </a>
                                <div class="sub-category-menu">
                                    <div class="category-arrow"></div>
                                    <div class="sub-category-menu-inner">
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Стакан</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Тарелка</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Hutamaki"</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Наборы одноразовой посуды</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Столовые приборы</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые чашки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Барные украшения</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Ланчбоксы</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда из Литьевого полистерола Кристалл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые лотки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Super Party"</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пакет фасовочный ПВД, ПНД
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пакет Zip Lock
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Мешки хозяйственные
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пакет с пластмассовыми ручками
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пакеты бумажные
                                </a>
                            </li>
                            <li class="categories__item ">
                                <a href="" class="categories__link">
                                    Одноразовая посуда
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Хозяйственные товары
                                </a>
                            </li>
                            <li class="categories__item ">
                                <a href="" class="categories__link">
                                    Подарочные пакеты
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пленка стрейч
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Скатерти
                                </a>
                            </li>
                            <li class="categories__item ">
                                <a href="" class="categories__link">
                                    Салфетки
                                </a>
                            </li>
                            <li class="categories__item ">
                                <a href="" class="categories__link">
                                    Сумки полипропиленовые
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Фольга
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пакеты бумажные с ручками
                                </a>
                            </li>
                            <li class="categories__item ">
                                <a href="" class="categories__link">
                                    Подарочная упаковка
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Бытовая химия
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Канцтовары
                                </a>
                            </li>
                            <li class="categories__item categories__item_blue">
                                <a href="" class="categories__link">
                                    Пакеты с логотипами
                                </a>
                            </li>
                            <li class="categories__item categories__item_blue">
                                <a href="" class="categories__link">
                                    Пленка с печатью
                                </a>
                            </li>
                            <li class="categories__item categories__item_blue">
                                <a href="" class="categories__link">
                                    Гибкая упаковка с печатью
                                </a>
                            </li>
                            <li class="categories__item categories__item_blue">
                                <a href="" class="categories__link">
                                    Пакеты Дой-пак (Doy-pack)
                                </a>
                            </li>
                            <li class="categories__item categories__item_blue">
                                <a href="" class="categories__link">
                                    Упаковка флоупак (Флоу-пак)
                                </a>
                            </li>
                        </ul>

                    </aside>
                    <div class="content-right">

                        <div class="breadcrumbs">
                            <ul>
                                <li>
                                    <a href="#">Главная</a>
                                </li>
                                <li>
                                    <span>Вакансии</span>
                                </li>
                            </ul>
                        </div>

                        <div class="content-main">
                            <h1 class="page-title">Производство полиэтиленовых пакетов с нанесением рисунка или логотипа</h1>

                            <p>
                                Нанесение рисунка с логотипом давно уже стало неотъемлемой частью технологии производства
                                полиэтиленовых пакетов. Автоматические линии оборудованы коронаторами и флексомашинами,
                                которые вмиг превращают бесцветную полиэтиленовую пленку в произведение искусства.
                            </p>
                            <img src="static/img/novosti-item-img.jpg" alt="a" align="left">
                            <p>Нанесение рисунка с логотипом давно уже стало неотъемлемой частью технологии производства
                                полиэтиленовых пакетов. Автоматические линии оборудованы коронаторами и флексомашинами,
                                которые вмиг превращают бесцветную полиэтиленовую пленку в произведение искусства.</p>
                            <p>
                                получить шедевр на полиэтилене. Вы тратите лишние деньги и время, работая с посредником.
                                Заказав ту же продукцию у производителя непосредственно, вы сохраните (все равно, что заработаете)
                                значительные средства.
                            </p>
                            <h4>
                                <strong>Рассмотрим один момент из жизни.</strong>
                            </h4>
                            <p>Вы намерены к юбилею предприятия раздать гостям памятные подарки. Конечно же их лучше
                                положить не в пакет майка, купленный в ближайшем супермаркете, а в кулек с красивой
                                многоцветной картинкой. На картинке разместить логотип, памятную надпись с датой. Ваш
                                менеджер звонит в ближайшее дизайнерское агентство и договаривается о производстве
                                полиэтиленовых пакетов с нанесением рисунка в количестве 200 штук. Цена их будет чуть ли
                                ни вровень с самими подарками!</p>
                            <p>Вы тратите лишние деньги и время, работая с посредником. Заказав ту же продукцию у
                                производителя непосредственно, вы сохраните (все равно, что заработаете) значительные
                                средства.</p>
                            <p>Обычно, производитель полиэтиленовых пакетов имеет в технологической линии коронер и
                                флексомашину – необходимое оборудование для печати при массовом производстве. Но, он же
                                изготавливает пакеты для шелкографии и работает в тесном сотрудничестве с предприятием,
                                наносящем рисунок этим способом. И цена для него будет гораздо ниже, чем для другого
                                посредника.</p>
                            <p>К недостаткам шелкографии относят высокую себестоимость, а значит и цену продукции.
                                Однако, клиент часто идет на это, когда ему необходимо срочно изготовить небольшую
                                партию пакетов к какой-то знаменательной дате или акции.</p>
                            <p>Мы очень просто договариваемся с нашими партнерами по бизнесу и клиентами. Даже, если
                                какую то услугу мы не можем оказать сами, в кратчайший срок вопрос будет решен. Заказать
                                полиэтиленовые пакеты с рисунком у нас – это равно - сэкономить время, нервы и деньги,
                                получив при этом продукцию высокого качества. </p>

                            <a href="#" class="news-back">к списку статей»</a>

                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>

    <?php require_once('template/footer.php') ?>

</div>

</body>
</html>