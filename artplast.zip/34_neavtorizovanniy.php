<!DOCTYPE html>
<html lang="ru">
<head>

    <meta charset="UTF-8">
    <!--<meta name="viewport" content="width=device-width, initial-scale=1.0">-->
    <meta name="description" content="описание страницы">
    <meta name="keywords" content="ключевое слово1, ключевое слово2">

    <title>Карта сайта</title>

    <link rel="stylesheet" href="static/css/style.min.css"/>

</head>
<body>

<div class="wrapper">
    <div class="main">
        <div class="all">

            <?php require_once('template/header.php') ?>

            <div class="main-content">
                <div class="container">
                    <aside class="sidebar">

                        <ul class="categories">
                            <li class="categories__item categories__item_drop">
                                <a href="" class="categories__link">
                                    Пакет с петлевой ручкой
                                </a>
                                <div class="sub-category-menu">
                                    <div class="category-arrow"></div>
                                    <div class="sub-category-menu-inner">
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Стакан</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Тарелка</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Hutamaki"</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Наборы одноразовой посуды</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Столовые приборы</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые чашки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Барные украшения</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Ланчбоксы</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда из Литьевого полистерола Кристалл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые лотки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Super Party"</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пакеты с вырубной ручкой
                                </a>
                            </li>
                            <li class="categories__item categories__item_drop">
                                <a href="" class="categories__link">
                                    Пакет майка
                                </a>
                                <div class="sub-category-menu">
                                    <div class="category-arrow"></div>
                                    <div class="sub-category-menu-inner">
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Стакан</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Тарелка</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Hutamaki"</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Наборы одноразовой посуды</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Столовые приборы</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые чашки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Барные украшения</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Ланчбоксы</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда из Литьевого полистерола Кристалл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые лотки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Super Party"</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="categories__item categories__item_drop">
                                <a href="" class="categories__link">
                                    Пленка пищевая
                                </a>
                                <div class="sub-category-menu">
                                    <div class="category-arrow"></div>
                                    <div class="sub-category-menu-inner">
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Стакан</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Тарелка</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Hutamaki"</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Наборы одноразовой посуды</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Столовые приборы</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые чашки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Барные украшения</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Ланчбоксы</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда из Литьевого полистерола Кристалл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые лотки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Super Party"</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="categories__item categories__item_drop">
                                <a href="" class="categories__link">
                                    Скотч
                                </a>
                                <div class="sub-category-menu">
                                    <div class="category-arrow"></div>
                                    <div class="sub-category-menu-inner">
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Стакан</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Тарелка</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Hutamaki"</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Наборы одноразовой посуды</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Столовые приборы</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые чашки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Барные украшения</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Ланчбоксы</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда из Литьевого полистерола Кристалл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые лотки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Super Party"</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пакет фасовочный ПВД, ПНД
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пакет Zip Lock
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Мешки хозяйственные
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пакет с пластмассовыми ручками
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пакеты бумажные
                                </a>
                            </li>
                            <li class="categories__item ">
                                <a href="" class="categories__link">
                                    Одноразовая посуда
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Хозяйственные товары
                                </a>
                            </li>
                            <li class="categories__item ">
                                <a href="" class="categories__link">
                                    Подарочные пакеты
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пленка стрейч
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Скатерти
                                </a>
                            </li>
                            <li class="categories__item ">
                                <a href="" class="categories__link">
                                    Салфетки
                                </a>
                            </li>
                            <li class="categories__item ">
                                <a href="" class="categories__link">
                                    Сумки полипропиленовые
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Фольга
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пакеты бумажные с ручками
                                </a>
                            </li>
                            <li class="categories__item ">
                                <a href="" class="categories__link">
                                    Подарочная упаковка
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Бытовая химия
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Канцтовары
                                </a>
                            </li>
                            <li class="categories__item categories__item_blue">
                                <a href="" class="categories__link">
                                    Пакеты с логотипами
                                </a>
                            </li>
                            <li class="categories__item categories__item_blue">
                                <a href="" class="categories__link">
                                    Пленка с печатью
                                </a>
                            </li>
                            <li class="categories__item categories__item_blue">
                                <a href="" class="categories__link">
                                    Гибкая упаковка с печатью
                                </a>
                            </li>
                            <li class="categories__item categories__item_blue">
                                <a href="" class="categories__link">
                                    Пакеты Дой-пак (Doy-pack)
                                </a>
                            </li>
                            <li class="categories__item categories__item_blue">
                                <a href="" class="categories__link">
                                    Упаковка флоупак (Флоу-пак)
                                </a>
                            </li>
                        </ul>

                    </aside>
                    <div class="content-right">

                        <div class="breadcrumbs">
                            <ul>
                                <li>
                                    <a href="#">Главная</a>
                                </li>
                                <li>
                                    <span>Вакансии</span>
                                </li>
                            </ul>
                        </div>

                        <div class="content-main">
                            <h1 class="page-title page-title--custom">Оформление заказа</h1>

                            <div class="top-steps">
                                <div class="top-steps__item">
                                    <a href="">1 шаг</a>
                                    <p class="top-steps__descr ">Просмотр корзины</p>
                                </div>
                                <div class="top-steps__item active">
                                    <a href="">2 шаг</a>
                                    <p class="top-steps__descr ">Просмотр корзины</p>
                                </div>
                                <div class="top-steps__item ">
                                    <a href="">3 шаг</a>
                                    <p class="top-steps__descr">Просмотр корзины</p>
                                </div>
                            </div>

                            <div class="order-buyer order-buyer--noauth">
                                <div class="order-buyer__top">
                                    <div class="order-buyer__top-left">
                                        <h3>Новый покупатель</h3>
                                        <p>(купить без регистрации)</p>
                                    </div>
                                    <div class="order-buyer__top-right">
                                        <p>
                                            Я уже зарегистрирован <a href="">Войти</a> <br>
                                            Я хочу <a href="">Зарегистрироваться</a>
                                            <a href="" class="why-register">Что дает регистрация?</a>
                                        </p>
                                    </div>
                                </div>

                                <ul class="order-buyer__list">
                                    <li class="order-buyer__item">
                                        <div class="order-buyer__item-left">
                                            <label for="order-buyer__label-name">
                                                Имя<span>*</span>
                                            </label>
                                        </div>
                                        <div class="order-buyer__item-right">
                                            <input type="text" id="order-buyer__label-name" value="">
                                        </div>
                                    </li>
                                    <li class="order-buyer__item">
                                        <div class="order-buyer__item-left">
                                            <label for="order-buyer__label-tel">
                                                Телефон<span>*</span>
                                            </label>
                                        </div>
                                        <div class="order-buyer__item-right">
                                            <input type="tel" class="myphone" id="order-buyer__label-tel" placeholder="+7 (___) ___-__-__">
                                        </div>
                                    </li>
                                    <li class="order-buyer__item">
                                        <div class="order-buyer__item-left">
                                            <label class="order-buyer__lastlabel" for="order-buyer__label-mail">
                                                E-mail
                                            </label>
                                        </div>
                                        <div class="order-buyer__item-right">
                                            <input type="email" id="order-buyer__label-mail" placeholder="Обещаем, никакого спама">
                                            <p>Копия заказа будет выслана на данный адрес электронной почты</p>
                                        </div>
                                    </li>
                                </ul>

                            </div>

                            <div class="order-producing">
                                <h3 class="order-producing__title">Способ получения товара</h3>

                                <ul class="order-producing__list">
                                    <li class="order-producing__item">
                                        <div class="order-producing__item-left">
                                            <input type="radio" name="radio" id="order-producing__radio1" checked>
                                            <label for="order-producing__radio1">Доставка</label>
                                            <p><a href="">Условия доставки</a></p>
                                        </div>
                                        <div class="order-producing__item-center">
                                            <label class="order-producing__address" for="order-producing__address">Адрес:</label>
                                            <input type="text" class="order-producing__input-address" id="order-producing__address">
                                        </div>
                                        <div class="order-producing__item-right">

                                            <div class="file-input-producing">
                                                <input type="file" class="file-input-producing__field" id="">
                                                <span class="file-input-producing__label ">
                                                    Прикрепить схему проезда
                                                </span>
                                                <button class="file-delete"></button>
                                            </div>
                                            
                                        </div>
                                    </li>
                                    <li class="order-producing__item">
                                        <div class="order-producing__item-left">
                                            <input type="radio" name="radio" id="order-producing__radio2">
                                            <label for="order-producing__radio2">Самовывоз</label>
                                            <p>
                                                с подразделения: Воршавское шоссе, д. 141/34
                                                <a href="" class="link-driving-directions">
                                                    <span>Схема проезда</span>
                                                </a>
                                            </p>
                                            <a href="#" class="order-producing__btn">Выбрать другое подразделение</a>
                                        </div>
                                    </li>
                                </ul>

                            </div>

                            <div class="order-payment-method">

                                <div class="order-payment-method__top">
                                    <h3 class="order-payment-method__title">Способ оплаты</h3>
                                    <div class="file-input-payment ">
                                        <input type="file" class="file-input-payment__field" id="shipping-addresses-item__file">
                                        <span class="file-input-payment__label ">
                                            Прикрепить файл с реквизитами
                                        </span>
                                        <button class="file-delete"></button>
                                    </div>
                                </div>

                                <div class="order-payment-method__radios">
                                    <input type="radio" id="order-payment-method__radio1" name="order-payment-method__radio" checked>
                                    <label for="order-payment-method__radio1">Наличный расчет</label>

                                    <input type="radio" id="order-payment-method__radio2" name="order-payment-method__radio">
                                    <label for="order-payment-method__radio2">Безналичный расчет</label>
                                </div>

                            </div>

                            <div class="order-note-order">
                                <h3 class="order-note-order__title">Примечание к заказу</h3>
                                <p class="order-note-order__descr">Если необходим дополнить информацию, заполните ее в этом поле</p>
                                <textarea></textarea>
                            </div>

                            <div class="order-summ-bottom">
                                <a href="" class="order-summ-bottom__leftbtn">Продолжить покупки</a>
                                <a href="" class="order-summ-bottom__rightbtn">Оформить заказ</a>
                                <div class="order-summ-bottom__summa">
                                    <span>Сумма заказа:</span>
                                    <p>90 090,42</p>
                                </div>

                            </div>

                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>
    
    <?php require_once('template/footer.php') ?>

</div>


</body>
</html>