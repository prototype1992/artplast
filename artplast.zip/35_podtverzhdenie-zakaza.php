<!DOCTYPE html>
<html lang="ru">
<head>

    <meta charset="UTF-8">
    <!--<meta name="viewport" content="width=device-width, initial-scale=1.0">-->
    <meta name="description" content="описание страницы">
    <meta name="keywords" content="ключевое слово1, ключевое слово2">

    <title>Карта сайта</title>

    <link rel="stylesheet" href="static/css/style.min.css"/>

</head>
<body>

<div class="wrapper">
    <div class="main">
        <div class="all">

            <?php require_once('template/header.php') ?>

            <div class="main-content">
                <div class="container">
                    <aside class="sidebar">

                        <ul class="categories">
                            <li class="categories__item categories__item_drop">
                                <a href="" class="categories__link">
                                    Пакет с петлевой ручкой
                                </a>
                                <div class="sub-category-menu">
                                    <div class="category-arrow"></div>
                                    <div class="sub-category-menu-inner">
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Стакан</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Тарелка</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Hutamaki"</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Наборы одноразовой посуды</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Столовые приборы</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые чашки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Барные украшения</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Ланчбоксы</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда из Литьевого полистерола Кристалл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые лотки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Super Party"</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пакеты с вырубной ручкой
                                </a>
                            </li>
                            <li class="categories__item categories__item_drop">
                                <a href="" class="categories__link">
                                    Пакет майка
                                </a>
                                <div class="sub-category-menu">
                                    <div class="category-arrow"></div>
                                    <div class="sub-category-menu-inner">
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Стакан</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Тарелка</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Hutamaki"</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Наборы одноразовой посуды</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Столовые приборы</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые чашки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Барные украшения</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Ланчбоксы</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда из Литьевого полистерола Кристалл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые лотки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Super Party"</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="categories__item categories__item_drop">
                                <a href="" class="categories__link">
                                    Пленка пищевая
                                </a>
                                <div class="sub-category-menu">
                                    <div class="category-arrow"></div>
                                    <div class="sub-category-menu-inner">
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Стакан</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Тарелка</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Hutamaki"</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Наборы одноразовой посуды</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Столовые приборы</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые чашки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Барные украшения</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Ланчбоксы</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда из Литьевого полистерола Кристалл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые лотки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Super Party"</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="categories__item categories__item_drop">
                                <a href="" class="categories__link">
                                    Скотч
                                </a>
                                <div class="sub-category-menu">
                                    <div class="category-arrow"></div>
                                    <div class="sub-category-menu-inner">
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Стакан</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">
                                                        Одноразовые стаканы 180 мл
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Тарелка</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые стаканы 180 мл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Hutamaki"</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Наборы одноразовой посуды</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Столовые приборы</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые вилки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые чашки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Барные украшения</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Ланчбоксы</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда из Литьевого полистерола Кристалл</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовые лотки</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="sub-category-menu-section">
                                            <ul class="sub-category-menu-section__list">
                                                <li class="sub-category-menu-section__item">
                                                    <a href="#" class="sub-category-menu-section__link">Одноразовая посуда "Super Party"</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пакет фасовочный ПВД, ПНД
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пакет Zip Lock
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Мешки хозяйственные
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пакет с пластмассовыми ручками
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пакеты бумажные
                                </a>
                            </li>
                            <li class="categories__item ">
                                <a href="" class="categories__link">
                                    Одноразовая посуда
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Хозяйственные товары
                                </a>
                            </li>
                            <li class="categories__item ">
                                <a href="" class="categories__link">
                                    Подарочные пакеты
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пленка стрейч
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Скатерти
                                </a>
                            </li>
                            <li class="categories__item ">
                                <a href="" class="categories__link">
                                    Салфетки
                                </a>
                            </li>
                            <li class="categories__item ">
                                <a href="" class="categories__link">
                                    Сумки полипропиленовые
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Фольга
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Пакеты бумажные с ручками
                                </a>
                            </li>
                            <li class="categories__item ">
                                <a href="" class="categories__link">
                                    Подарочная упаковка
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Бытовая химия
                                </a>
                            </li>
                            <li class="categories__item">
                                <a href="" class="categories__link">
                                    Канцтовары
                                </a>
                            </li>
                            <li class="categories__item categories__item_blue">
                                <a href="" class="categories__link">
                                    Пакеты с логотипами
                                </a>
                            </li>
                            <li class="categories__item categories__item_blue">
                                <a href="" class="categories__link">
                                    Пленка с печатью
                                </a>
                            </li>
                            <li class="categories__item categories__item_blue">
                                <a href="" class="categories__link">
                                    Гибкая упаковка с печатью
                                </a>
                            </li>
                            <li class="categories__item categories__item_blue">
                                <a href="" class="categories__link">
                                    Пакеты Дой-пак (Doy-pack)
                                </a>
                            </li>
                            <li class="categories__item categories__item_blue">
                                <a href="" class="categories__link">
                                    Упаковка флоупак (Флоу-пак)
                                </a>
                            </li>
                        </ul>

                    </aside>
                    <div class="content-right">

                        <div class="breadcrumbs">
                            <ul>
                                <li>
                                    <a href="#">Главная</a>
                                </li>
                                <li>
                                    <span>Вакансии</span>
                                </li>
                            </ul>
                        </div>

                        <div class="content-main">
                            <h1 class="page-title page-title--custom">Подтверждение заказа</h1>

                            <div class="top-steps">
                                <div class="top-steps__item">
                                    <a href="">1 шаг</a>
                                    <p class="top-steps__descr">Просмотр корзины</p>
                                </div>
                                <div class="top-steps__item">
                                    <a href="">2 шаг</a>
                                    <p class="top-steps__descr">Просмотр корзины</p>
                                </div>
                                <div class="top-steps__item active">
                                    <a href="">3 шаг</a>
                                    <p class="top-steps__descr">Просмотр корзины</p>
                                </div>
                            </div>

                            <div class="confirmation-of-an-order">
                                <div class="buyer-block">
                                    <h3 class="buyer-block__title">Покупатель</h3>
                                    
                                    <ul class="buyer-block__list">
                                        <li class="buyer-block__item">
                                            <span class="buyer-block__left">Имя:</span>
                                            <span class="buyer-block__right">Федоров Дмитрий Петрович</span>
                                        </li>
                                        <li class="buyer-block__item">
                                            <span class="buyer-block__left">Телефон:</span>
                                            <span class="buyer-block__right">+ 7 920 420 20 20</span>
                                        </li>
                                        <li class="buyer-block__item">
                                            <span class="buyer-block__left">E-mail:</span>
                                            <span class="buyer-block__right">f.dima@mail.ru</span>
                                        </li>
                                    </ul>

                                </div>
                                <div class="method-of-producing">
                                    <h3 class="method-of-producing__title">Способ получения товара</h3>
                                    <p>Доставка по адресу: г.Москва, ул. Заводская, д 3, кв 5 <a href="" class="method-of-producing__file">Прикреплена схема проезда</a></p>
                                </div>

                                <div class="payment-method">
                                    <h3 class="payment-method__title">Способ оплаты</h3>
                                    <p>Наличными при получении <a href="">Прикреплен файл с реквизитами</a></p>
                                </div>

                                <div class="note-to-order">
                                    <h3 class="note-to-order__title">Примечание к заказу</h3>
                                    <p>Домофон 36, с 10:00 до 22:00</p>
                                    <a href="">Изменить информацию</a>
                                </div>
                            </div>

                            <div class="total-block">
                                <h3 class="total-block__title">Итого:</h3>

                                <div class="total-block__right">
                                    <span class="total-block__summa">Сумма заказа:</span>
                                    <p class="total-block__price">90 090,42 a</p>
                                    <a href="" class="total-block__print">Распечатать заказ</a>
                                    <a href="" class="total-block__pdf">Сохранить в PDF</a>
                                </div>

                                <div class="total-block__info">
                                    <ul class="total-infolist">
                                        <li>
                                            <strong>Вес:</strong>
                                            <span>10.55 кг</span>
                                        </li>
                                        <li>
                                            <strong>Объем:</strong>
                                            <span>0.05 м</span>
                                        </li>
                                        <li>
                                            <strong>Кол-во мест:</strong>
                                            <span>3 шт</span>
                                        </li>
                                        <li>
                                            <strong>Кол-во позиция:</strong>
                                            <span>7</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="total-btn-group">
                                <a href="" class="btn-change-basket">Изменить состав корзины</a>
                                <a href="" class="btn-checkout">Оформить заказ</a>
                            </div>

                            <div class="order-list-wrap">
                                <h3 class="order-list-wrap__title">Состав заказа</h3>

                                <div class="frequently-bought">
                                    <div class="frequently-bought-top">
                                        <span class="frequently-bought-top__item frequently-bought-top__photo">Фото</span>
                                        <span class="frequently-bought-top__item frequently-bought-top__name">Наименования товара</span>
                                        <span class="frequently-bought-top__item frequently-bought-top__fas">Фасовка</span>
                                        <span class="frequently-bought-top__item frequently-bought-top__count">Количество / Цена</span>
                                        <span class="frequently-bought-top__item frequently-bought-top__summ">Сумма</span>
                                    </div>
                                    <ul class="frequently-bought-list">
                                        <li class="frequently-bought-list__item">
                                            <div class="frequently-bought-list__block frequently-bought-list__photo">
                                                <img src="static/img/frequently-bought-list__photo.jpg" alt="1">
                                            </div>
                                            <div class="frequently-bought-list__block frequently-bought-list__title-wr">
                                                <p class="frequently-bought-list__articul">
                                                    <span>Артикул:</span>7256827
                                                </p>
                                                <h3 class="frequently-bought-list__name">
                                                    <a href="">
                                                        300 мл (303460) Универсальное чист. средство (крем/молочко)
                                                        "EasyWork" (Универсальный крем для чистки любых поверхностей)
                                                        Россия
                                                    </a>
                                                </h3>
                                            </div>
                                            <p class="frequently-bought-list__block frequently-bought-list__fas">100/5000</p>
                                            <div class="frequently-bought-list__block frequently-bought-list__prices">

                                                <ul class="frequently-bought-list__count">
                                                    <li>
                                                        <p>Штук</p> <strong>500 х 0,42 р</strong>
                                                    </li>
                                                    <li>
                                                        <p>Упаковок</p> <span class="spancount-right">10 х 42 р</span>
                                                    </li>
                                                    <li>
                                                        <p>Мест</p> <span class="spancount-right2">0,2 х 2100 р</span>
                                                    </li>
                                                </ul>

                                            </div>
                                            <div class="frequently-bought-list__block frequently-bought-list__order">
                                                <p class="frequently-bought-list__price">30 090,42</p>
                                            </div>
                                        </li>
                                        <li class="frequently-bought-list__item">
                                            <div class="frequently-bought-list__block frequently-bought-list__photo">
                                                <img src="static/img/frequently-bought-list__photo.jpg" alt="1">
                                            </div>
                                            <div class="frequently-bought-list__block frequently-bought-list__title-wr">
                                                <p class="frequently-bought-list__articul">
                                                    <span>Артикул:</span>7256827
                                                </p>
                                                <h3 class="frequently-bought-list__name">
                                                    <a href="">
                                                        300 мл (303460) Универсальное чист. средство (крем/молочко)
                                                        "EasyWork" (Универсальный крем для чистки любых поверхностей)
                                                        Россия
                                                    </a>
                                                </h3>
                                            </div>
                                            <p class="frequently-bought-list__block frequently-bought-list__fas">100/5000</p>
                                            <div class="frequently-bought-list__block frequently-bought-list__prices">

                                                <ul class="frequently-bought-list__count">
                                                    <li>
                                                        <p>Штук</p> <strong>500 х 0,42 р</strong>
                                                    </li>
                                                    <li>
                                                        <p>Упаковок</p> <span class="spancount-right">10 х 42 р</span>
                                                    </li>
                                                    <li>
                                                        <p>Мест</p> <span class="spancount-right2">0,2 х 2100 р</span>
                                                    </li>
                                                </ul>

                                            </div>
                                            <div class="frequently-bought-list__block frequently-bought-list__order">
                                                <p class="frequently-bought-list__price">30 090,42</p>
                                            </div>
                                        </li>
                                        <li class="frequently-bought-list__item">
                                            <div class="frequently-bought-list__block frequently-bought-list__photo">
                                                <img src="static/img/frequently-bought-list__photo.jpg" alt="1">
                                            </div>
                                            <div class="frequently-bought-list__block frequently-bought-list__title-wr">
                                                <p class="frequently-bought-list__articul">
                                                    <span>Артикул:</span>7256827
                                                </p>
                                                <h3 class="frequently-bought-list__name">
                                                    <a href="">
                                                        300 мл (303460) Универсальное чист. средство (крем/молочко)
                                                        "EasyWork" (Универсальный крем для чистки любых поверхностей)
                                                        Россия
                                                    </a>
                                                </h3>
                                            </div>
                                            <p class="frequently-bought-list__block frequently-bought-list__fas">100/5000</p>
                                            <div class="frequently-bought-list__block frequently-bought-list__prices">

                                                <ul class="frequently-bought-list__count">
                                                    <li>
                                                        <p>Штук</p> <strong>500 х 0,42 р</strong>
                                                    </li>
                                                    <li>
                                                        <p>Упаковок</p> <span class="spancount-right">10 х 42 р</span>
                                                    </li>
                                                    <li>
                                                        <p>Мест</p> <span class="spancount-right2">0,2 х 2100 р</span>
                                                    </li>
                                                </ul>

                                            </div>
                                            <div class="frequently-bought-list__block frequently-bought-list__order">
                                                <p class="frequently-bought-list__price">30 090,42</p>
                                            </div>
                                        </li>
                                        <li class="frequently-bought-list__item">
                                            <div class="frequently-bought-list__block frequently-bought-list__photo">
                                                <img src="static/img/frequently-bought-list__photo.jpg" alt="1">
                                            </div>
                                            <div class="frequently-bought-list__block frequently-bought-list__title-wr">
                                                <p class="frequently-bought-list__articul">
                                                    <span>Артикул:</span>7256827
                                                </p>
                                                <h3 class="frequently-bought-list__name">
                                                    <a href="">
                                                        300 мл (303460) Универсальное чист. средство (крем/молочко)
                                                        "EasyWork" (Универсальный крем для чистки любых поверхностей)
                                                        Россия
                                                    </a>
                                                </h3>
                                            </div>
                                            <p class="frequently-bought-list__block frequently-bought-list__fas">100/5000</p>
                                            <div class="frequently-bought-list__block frequently-bought-list__prices">

                                                <ul class="frequently-bought-list__count">
                                                    <li>
                                                        <p>Штук</p> <strong>500 х 0,42 р</strong>
                                                    </li>
                                                    <li>
                                                        <p>Упаковок</p> <span class="spancount-right">10 х 42 р</span>
                                                    </li>
                                                    <li>
                                                        <p>Мест</p> <span class="spancount-right2">0,2 х 2100 р</span>
                                                    </li>
                                                </ul>

                                            </div>
                                            <div class="frequently-bought-list__block frequently-bought-list__order">
                                                <p class="frequently-bought-list__price">30 090,42</p>
                                            </div>
                                        </li>
                                    </ul>
                                </div>

                            </div>

                            <div class="total-block">
                                <h3 class="total-block__title">Итого:</h3>

                                <div class="total-block__right">
                                    <span class="total-block__summa">Сумма заказа:</span>
                                    <p class="total-block__price">90 090,42 a</p>
                                    <a href="" class="total-block__print">Распечатать заказ</a>
                                    <a href="" class="total-block__pdf">Сохранить в PDF</a>
                                </div>

                                <div class="total-block__info">
                                    <ul class="total-infolist">
                                        <li>
                                            <strong>Вес:</strong>
                                            <span>10.55 кг</span>
                                        </li>
                                        <li>
                                            <strong>Объем:</strong>
                                            <span>0.05 м</span>
                                        </li>
                                        <li>
                                            <strong>Кол-во мест:</strong>
                                            <span>3 шт</span>
                                        </li>
                                        <li>
                                            <strong>Кол-во позиция:</strong>
                                            <span>7</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="total-btn-group">
                                <a href="" class="btn-change-basket">Изменить состав корзины</a>
                                <a href="" class="btn-checkout">Оформить заказ</a>
                            </div>

                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>

    <?php require_once('template/footer.php') ?>

</div>


</body>
</html>